const express=require('express');const path=require('path');const cors=require('cors');const dns=require('dns');dns.setServers(['8.8.8.8','1.1.1.1']);require('dotenv').config({path:path.join(__dirname,'.env')});
const app=express();app.use(cors({origin:'*'}));app.use(express.json());require('./config/db')();app.use('/api',require('./routes/api'));app.use(express.static(path.join(__dirname,'../client')));
app.get('*',(req,res)=>{if(req.path.startsWith('/api'))return res.status(404).json({error:'not found'});res.sendFile(path.join(__dirname,'../client/index.html'));});
app.listen(5000,'0.0.0.0',()=>console.log('USER READY 5000'));

module.exports = app;
