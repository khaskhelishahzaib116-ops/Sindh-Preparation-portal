const mongoose=require('mongoose');
const dns=require('dns');
dns.setServers(['8.8.8.8','1.1.1.1']);
module.exports=async()=>{
  console.log('⏳ Connecting Mongo...');
  try{
    await mongoose.connect(process.env.MONGO_URI,{serverSelectionTimeoutMS:20000});
    console.log('✅ MONGO CONNECTED');
  }catch(e){console.log('❌ MONGO FAIL:',e.message)}
}
