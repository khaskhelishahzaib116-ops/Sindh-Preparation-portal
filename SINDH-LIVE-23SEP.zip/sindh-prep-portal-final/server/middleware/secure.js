const rateLimit=require('express-rate-limit'); const helmet=require('helmet');
module.exports={
 helmet:helmet({contentSecurityPolicy:false}),
 limiter:rateLimit({windowMs:15*60*1000,max:500}),
 authLimiter:rateLimit({windowMs:15*60*1000,max:20,message:{error:'Too many attempts'}})
}
