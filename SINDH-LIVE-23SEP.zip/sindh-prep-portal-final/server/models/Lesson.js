const m=require('mongoose');
module.exports=m.model('Lesson', new m.Schema({
subject:String, topic:String, heading:String, content:String
},{timestamps:true}));
