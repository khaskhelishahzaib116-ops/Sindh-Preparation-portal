const mongoose=require('mongoose');
const s=new mongoose.Schema({name:String,slug:String},{timestamps:true});
module.exports=mongoose.models.Subject||mongoose.model('Subject',s);
