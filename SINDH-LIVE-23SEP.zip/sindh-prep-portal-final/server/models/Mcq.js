const m=require('mongoose');
module.exports=m.model('Mcq', new m.Schema({subject:String, question:String, options:[String], correct:Number},{timestamps:true}));
