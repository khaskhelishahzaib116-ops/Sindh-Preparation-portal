const m=require('mongoose');
module.exports=m.model('Job', new m.Schema({
title:String, dept:String, lastDate:String, applyLink:String, desc:String
},{timestamps:true}));
