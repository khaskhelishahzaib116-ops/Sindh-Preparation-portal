const mongoose=require('mongoose');
const s=new mongoose.Schema({name:String,score:Number,total:Number,pct:Number},{timestamps:true});
module.exports=mongoose.models.Result||mongoose.model('Result',s);
