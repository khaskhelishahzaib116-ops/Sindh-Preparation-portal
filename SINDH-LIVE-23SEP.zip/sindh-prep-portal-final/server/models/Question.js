const mongoose=require('mongoose');
const s=new mongoose.Schema({question:String,options:[String],correct:Number},{timestamps:true});
module.exports=mongoose.models.Question||mongoose.model('Question',s);
