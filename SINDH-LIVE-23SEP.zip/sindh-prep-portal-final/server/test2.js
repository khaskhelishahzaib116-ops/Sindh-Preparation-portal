require('dotenv').config();
const m=require('mongoose');
console.log('Connecting... please wait 5 sec');
m.connect(process.env.MONGO_URI,{serverSelectionTimeoutMS:8000}).then(()=>{
 console.log('✅ MONGO CONNECTED - AB PROJECT CHALEGA');
 process.exit(0);
}).catch(e=>{
 console.log('❌ STILL FAIL:',e.message);
 console.log('Atlas me 0.0.0.0/0 add kiya ya nahi?');
 process.exit(1);
});
