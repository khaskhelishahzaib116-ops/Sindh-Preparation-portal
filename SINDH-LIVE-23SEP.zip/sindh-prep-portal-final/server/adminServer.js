const express=require('express');const path=require('path');const cors=require('cors');const dns=require('dns');dns.setServers(['8.8.8.8','1.1.1.1']);require('dotenv').config({path:path.join(__dirname,'.env')});
const app=express();app.use(cors({origin:'*'}));app.use(express.json());require('./config/db')();app.use('/admin-api',require('./routes/admin'));
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'../client/admin.html')));app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'../client/admin.html')));
app.listen(5001,'0.0.0.0',()=>console.log('ADMIN READY 5001'));
