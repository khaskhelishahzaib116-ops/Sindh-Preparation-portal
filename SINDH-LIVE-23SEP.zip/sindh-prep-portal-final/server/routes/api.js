const express=require('express');const router=express.Router();const fs=require('fs');const path=require('path');const mongoose=require('mongoose');
const U=path.join(__dirname,'users.json');const J=path.join(__dirname,'jobs.json');const L=path.join(__dirname,'library.json');const M=path.join(__dirname,'mcqs.json');
[U,J,L,M].forEach(f=>{if(!fs.existsSync(f))fs.writeFileSync(f,'[]')});
const rd=f=>{try{return JSON.parse(fs.readFileSync(f))}catch{return[]}};const wr=(f,d)=>fs.writeFileSync(f,JSON.stringify(d,null,2));
let User,Mcq;try{User=require('../models/User')}catch{}try{Mcq=require('../models/Mcq')}catch{}
router.post('/register',async(req,res)=>{const{name,email,password,phone}=req.body;if(!name||!email||!password||!phone)return res.status(400).json({error:'All required'});try{if(mongoose.connection.readyState===1){if(await User.findOne({email}))return res.status(400).json({error:'Exists'});const u=await User.create({name,email,password,phone});return res.json({success:true,user:u});}throw 0}catch{let u=rd(U);if(u.find(x=>x.email===email))return res.status(400).json({error:'Exists'});let nu={_id:Date.now(),name,email,password,phone};u.push(nu);wr(U,u);return res.json({success:true,user:nu});}});
router.post('/login',async(req,res)=>{const{email,password}=req.body;try{if(mongoose.connection.readyState===1){const u=await User.findOne({email});if(!u)return res.status(400).json({error:'Not found'});if(u.password!==password)return res.status(400).json({error:'Wrong'});return res.json({success:true,user:{name:u.name,email:u.email,phone:u.phone,id:u._id}});}throw 0}catch{const u=rd(U).find(x=>x.email===email&&x.password===password);if(!u)return res.status(400).json({error:'Not found'});return res.json({success:true,user:u});}});
router.get('/jobs',async(req,res)=>{try{if(mongoose.connection.readyState===1){const Job=require('../models/Job');return res.json(await Job.find());}throw 0}catch{res.json(rd(J));}});
router.get('/library',(req,res)=>res.json(rd(L)));
router.get('/mcqs',async(req,res)=>{try{if(mongoose.connection.readyState===1)return res.json(await Mcq.find());throw 0}catch{res.json(rd(M));}});
module.exports=router;
