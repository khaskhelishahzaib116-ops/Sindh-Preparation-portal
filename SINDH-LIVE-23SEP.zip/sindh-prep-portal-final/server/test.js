require('dotenv').config();
const mongoose=require('mongoose');
console.log('URI:',process.env.MONGO_URI?.slice(0,30));
mongoose.connect(process.env.MONGO_URI).then(()=>{console.log('✅ MONGO CONNECTED');process.exit(0)}).catch(e=>{console.log('❌ FAIL:',e.message);process.exit(1)});
